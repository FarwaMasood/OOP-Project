Getting Started
Our project has data from 1feb 2024 to 29 feb 2024.
1.Clone the repository to your local machine.
2.Open the project in your preferred C++ development environment.
3.Compile and run the application.
Usage
1.Launch the application.
2.Select the destination and input the travel date.
3.Choose your preferred airline, time slot, and class.
4.Use the seat map for real-time seat selection.
5.Confirm your reservation, and your details will be securely stored.
6.Sign in to view your flight details using your passport number.
7.Utilize the cancellation feature if needed to free up seats.

Contact
If you have any questions or issues, please contact at farwamasood09@gmail.com.

Happy Flying!
