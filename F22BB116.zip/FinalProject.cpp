#include <iostream>  //input and output
#include <fstream>   //file functions
#include <windows.h> //terminal width
#include <cstring>   //strcpy ,strlen
#include <conio.h>   //_getch
#include <algorithm> //find
#include <string>    //substring
#include <iomanip>   //setw   to enhance readability of a file
#include <cstdio>    //for remove and rename
using namespace std;
string yairline[50];
string ydeparture_time[50];
string yarrival_time[50];
string yflight_number[50];
int y_BA;
int y_BB;
int y_EA;
int y_EB;
int i = 1;
string pnr_number;
string seat_filename;
void options();
void set_flights();
int opt;

int get_terminal_width()
{
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
    return csbi.srWindow.Right - csbi.srWindow.Left + 1;
}
void gotoxy(int x, int y)
{
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
class User
{
private:
    string first_name;
    string last_name;
    string passport_no;
    string id;
    string email_address;

public:
    User() = default; // default constructor
    // taking input from user
    void initialize_user()
    {
        cout << "Enter your first name:  ";
        cin >> first_name;
        cout << "Enter your last name:  ";
        cin >> last_name;
        cout << "Enter your Passport Number:  ";
        cin >> passport_no;
        cout << "Enter Your Id:  ";
        cin >> id;
        cout << "Enter Your Email Address:  ";
        cin >> email_address;
    }
    // getters for the private variables
    string getPassportNo() { return passport_no; }
    string getFirstName() { return first_name; }
    string getLastName() { return last_name; }
    string getId() { return id; }
    string getEmailAddress() { return email_address; }
};
class Destination : public User
{ // class inherited from user
public:
    string country_name;
    int country_code;
    string city_name;
    Destination() = default; // default constructor
    // taking input from user
    void initialize_destination()
    {
        cout << "Choose your destination" << endl;
        cout << "1. United Arab Emirates" << endl;
        cout << "2. Saudi Arabia" << endl;
        cout << "3. Qatar" << endl;
        int ch;
        cout << "Enter your choice (1-3):  ";
        cin >> ch;
        switch (ch)
        {
        case 1:
            cout << "You are travelling to United Arab Emirates" << endl;
            country_name = "United Arab Emirates";
            country_code = 784;
            city_name = "Dubai";
            break;
        case 2:
            cout << "You are travelling to Saudi Arabia" << endl;
            country_name = "Saudi Arabia";
            country_code = 682;
            city_name = "Jeddah";
            break;
        case 3:
            cout << "You are travelling to Qatar" << endl;
            country_name = "Qatar";
            country_code = 634;
            city_name = "Doha";
            break;
        default:
            cout << "Invalid choice" << endl;
            initialize_destination();
        }
    }
};
class Flights : public Destination
{ // inherited from Destination
public:
    string date;
    Flights() = default; // default constructor
    // taking travel date from user
    void initialize_flights()
    {
        cout << "Enter Date Of Journey (DDMMYY). "
             << "Please enter a valid date:  ";
        cin >> date;
    }
    string airline_name;
    string departure_time;
    string arrival_time;
    string flight_number;
    void save_data()
    {
        // saving data in a file
        string fileName = getPassportNo() + ".txt";

        // Opening the file for writing
        ofstream outputFile(fileName);

        // Checking if the file is opened successfully
        if (!outputFile.is_open())
        {
            cerr << "Error opening the file!" << endl;
            return;
        }
        string seat_class = (opt == 1) ? "Business" : "Economy";
        // Writing data to the file
        outputFile << "First Name: " << getFirstName() << endl;
        outputFile << "Last Name: " << getLastName() << endl;
        outputFile << "ID Number: " << getId() << endl;
        outputFile << "Email Address: " << getEmailAddress() << endl;
        outputFile << "Flight details for Passport No: " << getPassportNo() << endl;
        outputFile << "Flight Number: " << flight_number << endl;
        outputFile << "Date of Travel (DDMMYY): " << date << endl;
        outputFile << "Destination: " << country_name << endl;
        outputFile << "Destination Code: " << country_code << endl;
        outputFile << "City of Arrival: " << city_name << endl;
        outputFile << "Airline_Name: " << airline_name << endl;
        outputFile << "Departure Time: " << departure_time << endl;
        outputFile << "Arrival Time: " << arrival_time << endl;
        outputFile << "PNR number: " << pnr_number << endl;
        outputFile << "Seat Class: " << seat_class << endl;
        // Closing the file
        outputFile.close();
        cout << "Your seat has been reserved." << endl;
    }

    void displayLinesStartingWith(string filename, const string &startPattern)
    {
        // displaying lines starting with specified pattern
        ifstream inputFile(filename);
        if (!inputFile.is_open())
        {
            cerr << "Error opening the file!" << endl;
            return;
        }
        string line;
        int lineNumber = 0;
        i = 1;
        while (getline(inputFile, line))
        {
            lineNumber++;
            // Checking if the line starts with the given pattern
            if (line.compare(0, startPattern.length(), startPattern) == 0)
            {
                cout << i << ": ";
                cout << line << endl;

                yairline[i] = line.substr(14, 25);
                ydeparture_time[i] = line.substr(39, 7);
                yarrival_time[i] = line.substr(64, 7);
                yflight_number[i] = line.substr(85, 6);
                i++;
            }
        }
        // closing the file after reading
        inputFile.close();
    }
    void seats(string filename, string pnr, int opt)
    {
        ifstream inputFile(filename);
        ofstream outputFile("tempfile.txt");

        if (!inputFile.is_open() || !outputFile.is_open())
        {
            cerr << "Error opening files!" << endl;
            return;
        }
        string line;
        int lineNumber = 0;
        while (getline(inputFile, line))
        {
            lineNumber++;

            // Checking if the line starts with the given PNR
            if (line.find(pnr) != string::npos)
            {
                y_BA = stoi(line.substr(28, 3));
                y_BB = stoi(line.substr(36, 3));
                y_EA = stoi(line.substr(44, 3));
                y_EB = stoi(line.substr(52, 3));

                if (opt == 1)
                {
                    if (y_BA > 0)
                    {
                        line.replace(28, 3, to_string(y_BA - 1));
                        line.insert(28, string(3 - to_string(y_BA - 1).length(), '0'));

                        line.replace(36, 3, to_string(y_BB + 1));
                        line.insert(36, string(3 - to_string(y_BB + 1).length(), '0'));
                    }
                    else
                    {
                        cout << "No Business Class Seat available.Please select a different flight." << endl;
                        set_flights();
                    }
                }
                else if (opt == 2)
                {
                    if (y_EA > 0)
                    {
                        line.replace(44, 3, to_string(y_EA - 1));
                        line.insert(44, string(3 - to_string(y_EA - 1).length(), '0'));

                        line.replace(52, 3, to_string(y_EB + 1));
                        line.insert(52, string(3 - to_string(y_EB + 1).length(), '0'));
                    }
                    else
                    {
                        cout << "No Economy Class Seat available.Please select a different flight." << endl;
                        set_flights();
                    }
                }
                else
                {
                    cout << "Invalid Input.Please try again." << endl;
                    set_flights();
                }
            }
            // Writing the line to the output file
            outputFile << line << endl;
        }
        inputFile.close();
        outputFile.close();
        // Remove the original file and rename the temporary file
        remove(filename.c_str());
        rename("tempfile.txt", filename.c_str());
    }

    void cancel_flights()
    {
        // Get the file name from the user
        string passport;
        int choice;
        string city;
        cout << "Enter your passport number: ";
        cin >> passport;
        string filename = passport + ".txt";
        // cout<<filename<<endl;
        ifstream inputFile(filename);

        if (!inputFile.is_open())
        {
            cerr << "Please Enter valid Passport Number!" << endl;
            cancel_flights();
        }
        string line;
        int lineNumber = 0;
        string search1 = "City of Arrival: ";
        string city1;

        string search2 = "PNR number: ";
        string pnr1;

        string search3 = "Seat Class: ";
        string seat1;

        while (getline(inputFile, line))
        {
            lineNumber++;
            // Checking if the line starts with the given pattern
            if (line.compare(0, search1.length(), search1) == 0)
            {
                //  if (line.compare(0, startPattern.length(), startPattern) == 0)
                // cout << search1.length() << endl;
                city1 = line.substr(17, search1.length() - 18);
                // cout << city1 <<endl;
                // cout << search1 <<endl;
            }
            if (line.compare(0, search2.length(), search2) == 0)
            {
                // cout << search2.length() << endl;
                pnr1 = line.substr(12, search2.length() - 13);
                // cout<<search2<<endl;
                // cout << pnr1 <<endl;
            }
            if (line.compare(0, search3.length(), search3) == 0)
            {
                seat1 = line.substr(12, search3.length() - 13);
                // cout<<search3<<endl;
                // cout << seat1 <<endl;
            }
        }

        inputFile.close();
        string yseat_file2 = city1 + "_seats.txt";
        // cout << yseat_file2 << endl;
        ifstream inputFile2(yseat_file2);
        ofstream outputFile("tempfile.txt");
        if (!inputFile2.is_open() || !outputFile.is_open())
        {
            cerr << "Error opening files!" << endl;
            return;
        }
        lineNumber = 0;
        // cout<<pnr1<<endl;
        // cout<<seat1<<endl;
        while (getline(inputFile2, line))
        {
            lineNumber++;
            // Checking if the line starts with the given pattern

            if (line.compare(0, pnr1.length(), pnr1) == 0)
            {
                y_BA = stoi(line.substr(28, 3));
                y_BB = stoi(line.substr(36, 3));
                y_EA = stoi(line.substr(44, 3));
                y_EB = stoi(line.substr(52, 3));
                if (seat1 == "Business")
                {
                    line.replace(28, 3, to_string(y_BA + 1));
                    line.insert(28, string(3 - to_string(y_BA + 1).length(), '0'));
                    line.replace(36, 3, to_string(y_BB - 1));
                    line.insert(36, string(3 - to_string(y_BB - 1).length(), '0'));
                    // cout<<line<<endl;
                }
                else
                {
                    line.replace(44, 3, to_string(y_EA + 1));
                    line.insert(44, string(3 - to_string(y_EA + 1).length(), '0'));
                    line.replace(52, 3, to_string(y_EB - 1));
                    line.insert(52, string(3 - to_string(y_EB - 1).length(), '0'));
                    // cout<<line<<endl;
                }
            }
            // writing into the output file
            outputFile << line << endl;
        }
        inputFile2.close();
        outputFile.close();
        remove(yseat_file2.c_str());
        rename("tempfile.txt", yseat_file2.c_str());

        // Attempt to delete the file
        if (remove(filename.c_str()) != 0)
        {
            // If remove returns non-zero, an error occurred
            cerr << "Error deleting the file" << endl;
        }
        else
        {
            cout << "Reservation cancelled successfully" << endl;
        }
    }

    void set_flights()
    {
        int choice;
        string file_name = city_name + "_2024.txt";
        seat_filename = city_name + "_seats.txt";
        cout << "Date\t\tAirlines\t\tDeparture Time\t\tArrival Time\t\tFlight Number" << endl;
        displayLinesStartingWith(file_name, date);
        cout << "Enter your choice" << endl;
        cin >> choice;
        if (choice > 0 && choice < i)
        {
            airline_name = yairline[choice];
            departure_time = ydeparture_time[choice];
            arrival_time = yarrival_time[choice];
            flight_number = yflight_number[choice];
            pnr_number = city_name + "-" + date + "-" + flight_number;
            cout << "1.Business Class Seat" << endl;
            cout << "2.Economy Class Seat" << endl;
            cout << "Enter your choice (1-2): ";
            opt;
            cin >> opt;
            seats(seat_filename, pnr_number, opt);
            save_data();
        }
        else
        {
            cout << "Invalid Choice.Please try again." << endl;
            set_flights();
        }
    }
    void display_data(string passport)
    {
        string file_name = passport + ".txt";
        ifstream inputFile(file_name);

        // Checking if the file is opened successfully
        if (!inputFile.is_open())
        {
            cerr << "Error opening the file " << file_name << "!" << endl;
        }
        string line;
        while (getline(inputFile, line))
        {
            // displaying the content of the file
            cout << line << endl;
        }

        // Close the file
        inputFile.close();
    }
};

void menu_header(int temp, int temp_len)
{
    system("cls");
    int width = get_terminal_width();
    for (int i = 0; i < 7; i++)
    {
        for (int j = 0; j < width; j++)
        {
            cout << ("  ");
        }
        cout << ("\n");
    }
    gotoxy(0, 0);
    for (int i = 0; i < width; i++)
    {
        cout << ("^");
    }
    int centre = width / 2;
    gotoxy(centre - temp_len, 2);
    if (temp == 1)
    {
        cout << "Welcome to Flight Reservation System" << endl;
    }
    else if (temp == 2)
    {
        cout << "Options" << endl;
    }
    else if (temp == 3)
    {
        cout << "Thanks for using our Flight Reservation System" << endl;
    }
    cout << ("\n");
    for (int i = 0; i < width; i++)
    {
        cout << ("^");
    }
    cout << ("\n");
    cout << ("\n");
}

void main_menu()
{
    char myString2[] = "Options";
    int length2 = strlen(myString2);
    menu_header(2, length2);
    cout << "1) Reserve a flight." << endl;
    cout << "2) View your flight details." << endl;
    cout << "3) Cancel Your Reservation." << endl;
    cout << "4) Exit." << endl;
    options();
}

void options()
{
    int ch;
    cout << "Please enter your choice: ";
    cin >> ch;
    switch (ch)
    {
    case 1:
    {
        Flights a1;
        a1.initialize_user();
        a1.initialize_destination();
        a1.initialize_flights();
        a1.set_flights();
        cout << "Press any key to go back to Main Menu" << endl;
        ch = _getch();
        main_menu();
        break;
    }
    case 2:
    {
        string passport;
        cout << "Please enter your passport number to see your reservation details: ";
        cin >> passport;
        Flights a1;
        a1.display_data(passport);
        cout << "Press any key to go back to Main Menu" << endl;
        ch = _getch();
        main_menu();
        break;
    }
    case 3:
    {
        Flights a1;
        a1.cancel_flights();
        cout << "Press any key to go back to Main Menu" << endl;
        ch = _getch();
        main_menu();
        break;
    }
    case 4:
    {
        system("cls");
        char myString3[] = "Thanks for using our Flight Reservation System";
        int length3 = strlen(myString3);
        menu_header(3, length3);
        exit(0);
        break;
    }
    default:
    {
        cout << "Invalid Input.Please try again" << endl;
        main_menu();
    }
    }
}
void welcome()
{
    char ch;
    char myString1[] = "Welcome To A Flight Reservation System";
    int length1 = strlen(myString1);
    menu_header(1, length1);
    cout << "Press any key to continue" << endl;
    ch = _getch();
    main_menu();
}
int main()
{
    welcome();
    return 0;
}